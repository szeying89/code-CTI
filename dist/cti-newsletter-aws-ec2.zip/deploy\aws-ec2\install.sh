#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/cti-newsletter}"
SERVICE_USER="${SERVICE_USER:-cti-newsletter}"
PYTHON_BIN="${PYTHON_BIN:-python3}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "$PYTHON_BIN was not found. Install Python 3 first." >&2
  exit 1
fi

if ! id "$SERVICE_USER" >/dev/null 2>&1; then
  sudo useradd --system --create-home --shell /usr/sbin/nologin "$SERVICE_USER"
fi

sudo mkdir -p "$APP_DIR" "$APP_DIR/output" "$APP_DIR/logs"
sudo rm -rf "$APP_DIR/quick_jobs"
sudo cp -R "$PACKAGE_ROOT/quick_jobs" "$APP_DIR/quick_jobs"
sudo cp "$PACKAGE_ROOT/requirements.txt" "$APP_DIR/requirements.txt"
sudo cp "$PACKAGE_ROOT/cti_router_agent.md" "$APP_DIR/cti_router_agent.md"
sudo cp "$SCRIPT_DIR/run_last18h_cti_newsletter.sh" "$APP_DIR/run_last18h_cti_newsletter.sh"
sudo chmod +x "$APP_DIR/run_last18h_cti_newsletter.sh"

if [[ ! -f "$APP_DIR/.env" ]]; then
  sudo cp "$SCRIPT_DIR/env.example" "$APP_DIR/.env"
fi

sudo "$PYTHON_BIN" -m venv "$APP_DIR/.venv"
sudo "$APP_DIR/.venv/bin/python" -m pip install --upgrade pip
sudo "$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"

sudo sed \
  -e "s#__APP_DIR__#$APP_DIR#g" \
  -e "s#__SERVICE_USER__#$SERVICE_USER#g" \
  "$SCRIPT_DIR/cti-newsletter.service" | sudo tee /etc/systemd/system/cti-newsletter.service >/dev/null
sudo cp "$SCRIPT_DIR/cti-newsletter.timer" /etc/systemd/system/cti-newsletter.timer

sudo chown -R "$SERVICE_USER:$SERVICE_USER" "$APP_DIR"
sudo systemctl daemon-reload

cat <<EOF
Installed CTI newsletter job to $APP_DIR.

Next steps on the EC2 instance:
1. Edit $APP_DIR/.env and set FEEDLY_API_KEY.
2. Run once:
   sudo systemctl start cti-newsletter.service
3. View logs:
   sudo journalctl -u cti-newsletter.service -n 100 --no-pager
4. Enable scheduled runs:
   sudo systemctl enable --now cti-newsletter.timer
EOF
