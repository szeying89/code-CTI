#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/cti-newsletter}"
ENV_FILE="${ENV_FILE:-$APP_DIR/.env}"

cd "$APP_DIR"

if [[ -f "$ENV_FILE" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "$ENV_FILE"
  set +a
fi

if [[ -z "${FEEDLY_API_KEY:-}" && -z "${FEEDLY_TOKEN:-}" ]]; then
  echo "FEEDLY_API_KEY or FEEDLY_TOKEN must be set in $ENV_FILE" >&2
  exit 2
fi

LOOKBACK_HOURS="${CTI_LOOKBACK_HOURS:-18}"
TOP_ARTICLES="${CTI_TOP_ARTICLES:-4}"
OUTPUT_DOCX="${CTI_OUTPUT_DOCX:-output/cti_quick_newsletter.docx}"
OUTPUT_JSON="${CTI_OUTPUT_JSON:-output/cti_quick_newsletter.json}"

mkdir -p "$(dirname "$OUTPUT_DOCX")" "$(dirname "$OUTPUT_JSON")" logs

"$APP_DIR/.venv/bin/python" \
  "$APP_DIR/quick_jobs/last18h_cti_newsletter.py" \
  --hours "$LOOKBACK_HOURS" \
  --top "$TOP_ARTICLES" \
  --output "$OUTPUT_DOCX" \
  --json-report "$OUTPUT_JSON" \
  2>&1 | tee -a "logs/cti-newsletter.log"
