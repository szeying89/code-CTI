# AWS EC2 Deployment

This package deploys the CTI quick job on an AWS EC2 Linux instance. It creates a Python virtual environment, installs dependencies, adds a runner script, and registers an optional systemd timer.

## Instance Requirements

- Amazon Linux 2023, Ubuntu 22.04/24.04, or another modern Linux distribution.
- Python 3 and the `venv` module.
- Outbound HTTPS access to `api.feedly.com`.
- A Feedly API token.

For Ubuntu, install Python support if needed:

```bash
sudo apt-get update
sudo apt-get install -y python3 python3-venv unzip
```

For Amazon Linux 2023:

```bash
sudo dnf install -y python3 unzip
```

## Upload And Install

Upload `dist/cti-newsletter-aws-ec2.zip` to the EC2 instance, then run:

```bash
unzip cti-newsletter-aws-ec2.zip
cd cti-newsletter-aws-ec2
chmod +x deploy/aws-ec2/install.sh
./deploy/aws-ec2/install.sh
```

The default install path is `/opt/cti-newsletter`.

To use a custom path or service user:

```bash
APP_DIR=/srv/cti-newsletter SERVICE_USER=cti-newsletter ./deploy/aws-ec2/install.sh
```

## Configure Secrets

Edit the environment file:

```bash
sudo nano /opt/cti-newsletter/.env
```

Set:

```bash
FEEDLY_API_KEY=your_real_feedly_token
```

## Run Once

```bash
sudo systemctl start cti-newsletter.service
sudo journalctl -u cti-newsletter.service -n 100 --no-pager
```

Outputs are written to:

- `/opt/cti-newsletter/output/cti_quick_newsletter.docx`
- `/opt/cti-newsletter/output/cti_quick_newsletter.json`
- `/opt/cti-newsletter/logs/cti-newsletter.log`

## Schedule

The included timer runs every 6 hours:

```bash
sudo systemctl enable --now cti-newsletter.timer
systemctl list-timers cti-newsletter.timer
```

To change the schedule, edit:

```bash
sudo systemctl edit cti-newsletter.timer
```

Example override:

```ini
[Timer]
OnUnitActiveSec=3h
```

Then reload:

```bash
sudo systemctl daemon-reload
sudo systemctl restart cti-newsletter.timer
```

## Manual Run Without systemd

```bash
cd /opt/cti-newsletter
sudo -u cti-newsletter APP_DIR=/opt/cti-newsletter ./run_last18h_cti_newsletter.sh
```
