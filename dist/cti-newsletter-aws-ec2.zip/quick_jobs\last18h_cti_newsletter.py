#!/usr/bin/env python
"""
Quick CTI newsletter job.

Fetches recent Feedly security articles, ranks them for CTI relevance and impact,
selects the top articles, extracts CVEs / ATT&CK IDs / likely affected systems /
exploitation prerequisites, and writes a DOCX newsletter.

Required:
  FEEDLY_API_KEY environment variable, unless --input-json is used.
"""

from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import os
import re
import sys
import textwrap
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from docx import Document
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt


FEEDLY_BASE = "https://api.feedly.com"

FOCUS_TERMS = {
    "cyberattack": 9,
    "cyber attack": 9,
    "attack": 4,
    "ransomware": 10,
    "data breach": 9,
    "breach": 7,
    "intrusion": 7,
    "compromise": 7,
    "exploitation": 8,
    "actively exploited": 12,
    "zero-day": 12,
    "0-day": 12,
    "remote code execution": 10,
    "rce": 9,
    "supply chain": 12,
    "dependency": 6,
    "npm": 8,
    "pypi": 8,
    "github action": 7,
    "package": 5,
    "third-party": 6,
    "vendor": 4,
    "cybercrime": 10,
    "crime": 4,
    "extortion": 8,
    "phishing": 6,
    "credential": 6,
    "botnet": 6,
    "malware": 8,
    "bank": 9,
    "financial": 8,
    "payment": 8,
    "fintech": 7,
    "cryptocurrency": 6,
    "critical infrastructure": 8
}

EXCLUDE_TERMS = [
    "ics",
    "ot",
    "scada",
    "plc",
    "dcs",
    "industrial control system",
    "industrial control systems",
    "operational technology",
    "hmi"
]

TARGET_SYSTEM_HINTS = {
    "windows": "Windows systems",
    "linux": "Linux systems",
    "macos": "macOS systems",
    "android": "Android devices",
    "ios": "iOS devices",
    "chrome": "Chrome browsers",
    "edge": "Microsoft Edge browsers",
    "firefox": "Firefox browsers",
    "exchange": "Microsoft Exchange",
    "sharepoint": "Microsoft SharePoint",
    "active directory": "Microsoft Active Directory",
    "citrix": "Citrix systems",
    "fortinet": "Fortinet appliances",
    "palo alto": "Palo Alto Networks products",
    "cisco": "Cisco products",
    "ivanti": "Ivanti products",
    "vmware": "VMware products",
    "confluence": "Atlassian Confluence",
    "jira": "Atlassian Jira",
    "wordpress": "WordPress sites",
    "drupal": "Drupal sites",
    "oracle": "Oracle products",
    "sap": "SAP systems",
    "npm": "npm package ecosystem",
    "pypi": "Python Package Index ecosystem",
    "github": "GitHub repositories or workflows",
    "kubernetes": "Kubernetes environments",
    "docker": "Containerized environments",
    "cloud": "Cloud services",
    "aws": "AWS environments",
    "azure": "Microsoft Azure environments",
    "google cloud": "Google Cloud environments",
    "bank": "Financial-sector systems",
    "payment": "Payment systems"
}

ATTACK_HINTS = {
    "phishing": "T1566",
    "spearphishing": "T1566",
    "malicious link": "T1204.001",
    "malicious file": "T1204.002",
    "credential": "T1078",
    "valid account": "T1078",
    "brute force": "T1110",
    "exploit public-facing": "T1190",
    "public-facing application": "T1190",
    "remote code execution": "T1190",
    "rce": "T1190",
    "drive-by": "T1189",
    "supply chain": "T1195",
    "trusted relationship": "T1199",
    "powershell": "T1059.001",
    "command shell": "T1059",
    "web shell": "T1505.003",
    "ransomware": "T1486",
    "data encrypted": "T1486",
    "exfiltration": "T1041",
    "data theft": "T1041",
    "c2": "T1071",
    "command and control": "T1071",
    "lateral movement": "T1021",
    "privilege escalation": "T1068",
    "persistence": "T1547"
}


@dataclass
class Article:
    title: str
    url: str = ""
    source: str = ""
    published: dt.datetime | None = None
    summary: str = ""
    raw: dict[str, Any] = field(default_factory=dict)
    cves: list[str] = field(default_factory=list)
    attack_ids: list[str] = field(default_factory=list)
    targeted_systems: list[str] = field(default_factory=list)
    exploitation_prerequisites: list[str] = field(default_factory=list)
    relevance_score: float = 0.0
    impact_score: float = 0.0
    total_score: float = 0.0


def utc_now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def epoch_ms(value: dt.datetime) -> int:
    return int(value.timestamp() * 1000)


def clean_text(value: Any) -> str:
    if not value:
        return ""
    text = str(value)
    text = re.sub(r"<script[\s\S]*?</script>", " ", text, flags=re.I)
    text = re.sub(r"<style[\s\S]*?</style>", " ", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def parse_dt_ms(value: Any) -> dt.datetime | None:
    if value in (None, ""):
        return None
    try:
        number = int(value)
        if number > 10_000_000_000:
            return dt.datetime.fromtimestamp(number / 1000, tz=dt.timezone.utc)
        return dt.datetime.fromtimestamp(number, tz=dt.timezone.utc)
    except (TypeError, ValueError, OSError):
        return None


def http_json(method: str, url: str, token: str, body: Any | None = None) -> Any:
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "User-Agent": "cti-quick-job/1.0"
    }
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        details = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Feedly HTTP {exc.code} for {url}: {details}") from exc


def extract_entry_ids(payload: Any) -> list[str]:
    ids: list[str] = []

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                if key in {"entryId", "entryIds"}:
                    if isinstance(item, str):
                        ids.append(item)
                    elif isinstance(item, list):
                        ids.extend(str(x) for x in item if isinstance(x, str))
                else:
                    walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)

    walk(payload)
    return list(dict.fromkeys(ids))


def article_from_feedly_item(item: dict[str, Any]) -> Article | None:
    title = clean_text(item.get("title"))
    if not title:
        return None

    summary_parts = []
    for key in ("summary", "content", "leoSummary"):
        value = item.get(key)
        if isinstance(value, dict):
            if isinstance(value.get("sentences"), list):
                summary_parts.append(" ".join(clean_text(x) for x in value["sentences"]))
            summary_parts.append(clean_text(value.get("content")))
        elif isinstance(value, str):
            summary_parts.append(clean_text(value))

    url = item.get("canonicalUrl") or item.get("originId") or ""
    if not url and isinstance(item.get("alternate"), list) and item["alternate"]:
        url = item["alternate"][0].get("href", "")

    origin = item.get("origin") if isinstance(item.get("origin"), dict) else {}
    source = clean_text(origin.get("title") or item.get("source") or item.get("publisher"))
    published = (
        parse_dt_ms(item.get("published"))
        or parse_dt_ms(item.get("updated"))
        or parse_dt_ms(item.get("crawled"))
    )

    return Article(
        title=title,
        url=str(url),
        source=source,
        published=published,
        summary=clean_text(" ".join(x for x in summary_parts if x)),
        raw=item
    )


def extract_articles(payload: Any) -> list[Article]:
    articles: list[Article] = []

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            if value.get("title") and (
                value.get("canonicalUrl")
                or value.get("alternate")
                or value.get("originId")
                or value.get("summary")
                or value.get("content")
            ):
                article = article_from_feedly_item(value)
                if article:
                    articles.append(article)
            for item in value.values():
                walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)

    walk(payload)
    seen = set()
    unique: list[Article] = []
    for article in articles:
        key = (article.url or article.title).lower()
        if key not in seen:
            seen.add(key)
            unique.append(article)
    return unique


def fetch_entry_metadata(token: str, entry_ids: list[str]) -> list[Article]:
    if not entry_ids:
        return []
    articles: list[Article] = []
    for start in range(0, len(entry_ids), 100):
        chunk = entry_ids[start:start + 100]
        payload = http_json("POST", f"{FEEDLY_BASE}/v3/entries/.mget", token, chunk)
        articles.extend(extract_articles(payload))
    return articles


def feedly_search_body() -> dict[str, Any]:
    return {
        "layers": [
            {"severities": ["HIGH", "CRITICAL"], "type": "security"},
            {"type": "language", "languages": ["en"]}
        ],
        "source": {
            "items": [
                {
                    "type": "publicationBucket",
                    "id": "byf:cybersecurity-bundle",
                    "tier": "tier1"
                },
                {
                    "type": "publicationBucket",
                    "id": "cybersecurity:vulnerabilities",
                    "tier": "tier2"
                }
            ]
        }
    }


def fetch_feedly_articles(token: str, hours: int, count: int) -> list[Article]:
    cutoff = utc_now() - dt.timedelta(hours=hours)
    newer_than = epoch_ms(cutoff)
    articles: list[Article] = []

    trends = http_json("GET", f"{FEEDLY_BASE}/v3/trends/threats", token)
    articles.extend(extract_articles(trends))
    articles.extend(fetch_entry_metadata(token, extract_entry_ids(trends)))

    params = urllib.parse.urlencode({
        "count": min(max(count, 10), 100),
        "newerThan": newer_than,
        "includeAiActions": "true"
    })
    search_url = f"{FEEDLY_BASE}/v3/search/contents?{params}"
    search_payload = http_json("POST", search_url, token, feedly_search_body())
    articles.extend(extract_articles(search_payload))

    return filter_recent_articles(articles, cutoff)


def filter_recent_articles(articles: list[Article], cutoff: dt.datetime) -> list[Article]:
    filtered = []
    for article in articles:
        if article.published and article.published < cutoff:
            continue
        text = f"{article.title} {article.summary}".lower()
        if any(term in text for term in EXCLUDE_TERMS):
            continue
        filtered.append(article)
    return deduplicate(filtered)


def deduplicate(articles: list[Article]) -> list[Article]:
    seen = set()
    unique: list[Article] = []
    for article in articles:
        normalized_title = re.sub(r"[^a-z0-9]+", " ", article.title.lower()).strip()
        key = article.url.lower() or normalized_title
        if key in seen:
            continue
        seen.add(key)
        unique.append(article)
    return unique


def extract_cves(text: str) -> list[str]:
    return sorted(set(re.findall(r"CVE-\d{4}-\d{4,7}", text, flags=re.I)), key=str.upper)


def extract_attack_ids(text: str) -> list[str]:
    explicit = set(re.findall(r"T\d{4}(?:\.\d{3})?", text, flags=re.I))
    lowered = text.lower()
    inferred = {technique for hint, technique in ATTACK_HINTS.items() if hint in lowered}
    return sorted({item.upper() for item in explicit | inferred})


def extract_targeted_systems(text: str) -> list[str]:
    lowered = text.lower()
    systems = [label for hint, label in TARGET_SYSTEM_HINTS.items() if hint in lowered]
    return sorted(set(systems)) or ["Not specified in available article metadata"]


def extract_prerequisites(text: str) -> list[str]:
    lowered = text.lower()
    requirements: list[str] = []
    if "authentication required" in lowered or "authenticated" in lowered:
        requirements.append("Authentication or valid account may be required")
    if "unauthenticated" in lowered or "pre-auth" in lowered:
        requirements.append("No authentication may be required")
    if "user interaction" in lowered or "victim opens" in lowered or "malicious file" in lowered:
        requirements.append("User interaction may be required")
    if "remote" in lowered or "internet-facing" in lowered or "public-facing" in lowered:
        requirements.append("Network reachability to exposed service may be required")
    if "local" in lowered or "privilege escalation" in lowered:
        requirements.append("Local access or existing foothold may be required")
    if "supply chain" in lowered or "package" in lowered or "dependency" in lowered:
        requirements.append("Dependency consumption or trusted update path may be required")
    if not requirements:
        requirements.append("Not specified in available article metadata")
    return requirements


def score_article(article: Article, now: dt.datetime) -> Article:
    text = f"{article.title} {article.summary}".lower()
    relevance = sum(weight for term, weight in FOCUS_TERMS.items() if term in text)

    cves = extract_cves(f"{article.title} {article.summary}")
    attack_ids = extract_attack_ids(f"{article.title} {article.summary}")
    impact = 0.0
    impact += min(len(cves), 5) * 5
    impact += min(len(attack_ids), 5) * 3
    if re.search(r"\bcritical\b", text):
        impact += 8
    if "actively exploited" in text or "in the wild" in text:
        impact += 12
    if "ransomware" in text:
        impact += 10
    if "supply chain" in text:
        impact += 10
    if "financial" in text or "bank" in text or "payment" in text:
        impact += 8
    cvss_matches = [float(x) for x in re.findall(r"CVSS[^0-9]{0,12}([0-9](?:\.[0-9])?)", text, flags=re.I)]
    if cvss_matches:
        impact += max(cvss_matches)

    recency = 0.0
    if article.published:
        age_hours = max((now - article.published).total_seconds() / 3600, 0)
        recency = max(0, 18 - age_hours) / 18 * 10

    article.cves = cves
    article.attack_ids = attack_ids
    article.targeted_systems = extract_targeted_systems(text)
    article.exploitation_prerequisites = extract_prerequisites(text)
    article.relevance_score = round(relevance + recency, 2)
    article.impact_score = round(impact, 2)
    article.total_score = round((impact * 0.6) + (relevance * 0.35) + (recency * 0.05), 2)
    return article


def rank_articles(articles: list[Article]) -> list[Article]:
    now = utc_now()
    scored = [score_article(article, now) for article in articles]
    scored = [article for article in scored if article.relevance_score > 0 or article.impact_score > 0]
    return sorted(
        scored,
        key=lambda item: (
            item.total_score,
            item.impact_score,
            item.published or dt.datetime.min.replace(tzinfo=dt.timezone.utc)
        ),
        reverse=True
    )


def summarize_article(article: Article, max_sentences: int = 3) -> str:
    base = article.summary or article.title
    sentences = re.split(r"(?<=[.!?])\s+", base)
    selected = [clean_text(sentence) for sentence in sentences if clean_text(sentence)]
    if not selected:
        selected = [article.title]
    summary = " ".join(selected[:max_sentences])
    if len(summary.split()) > 85:
        summary = " ".join(summary.split()[:85]).rstrip(",.;") + "."
    return summary


def add_cell_text(cell, text: str, bold: bool = False) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run = paragraph.add_run(text)
    run.bold = bold
    run.font.size = Pt(9)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def format_table(table) -> None:
    table.style = "Table Grid"
    for row in table.rows:
        for cell in row.cells:
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after = Pt(0)
                for run in paragraph.runs:
                    run.font.size = Pt(9)


def write_newsletter(articles: list[Article], output_path: Path, hours: int) -> None:
    document = Document()
    section = document.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.7)
    section.right_margin = Inches(0.7)

    styles = document.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"].font.size = Pt(10)
    styles["Heading 1"].font.name = "Arial"
    styles["Heading 1"].font.size = Pt(16)
    styles["Heading 2"].font.name = "Arial"
    styles["Heading 2"].font.size = Pt(12)

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run = title.add_run("CTI Quick Newsletter")
    run.bold = True
    run.font.name = "Arial"
    run.font.size = Pt(20)

    subtitle = document.add_paragraph()
    subtitle.add_run(f"Top {len(articles)} articles from the last {hours} hours. Generated {utc_now().strftime('%Y-%m-%d %H:%M UTC')}.")

    document.add_heading("Priority Ranking", level=1)
    ranking_table = document.add_table(rows=1, cols=6)
    headers = ["Rank", "Title", "Source", "Published", "CVEs", "Score"]
    for index, header in enumerate(headers):
        add_cell_text(ranking_table.rows[0].cells[index], header, bold=True)
    for rank, article in enumerate(articles, start=1):
        row = ranking_table.add_row().cells
        add_cell_text(row[0], str(rank))
        add_cell_text(row[1], article.title)
        add_cell_text(row[2], article.source or "Unknown")
        add_cell_text(row[3], article.published.strftime("%Y-%m-%d %H:%M UTC") if article.published else "Unknown")
        add_cell_text(row[4], ", ".join(article.cves) if article.cves else "None identified")
        add_cell_text(row[5], str(article.total_score))
    format_table(ranking_table)

    for rank, article in enumerate(articles, start=1):
        document.add_heading(f"{rank}. {article.title}", level=1)
        meta = document.add_paragraph()
        meta.add_run("Source: ").bold = True
        meta.add_run(article.source or "Unknown")
        meta.add_run(" | Published: ").bold = True
        meta.add_run(article.published.strftime("%Y-%m-%d %H:%M UTC") if article.published else "Unknown")

        if article.url:
            url_para = document.add_paragraph()
            url_para.add_run("URL: ").bold = True
            url_para.add_run(article.url)

        document.add_heading("Summary", level=2)
        document.add_paragraph(summarize_article(article))

        document.add_heading("Technical Assessment", level=2)
        table = document.add_table(rows=5, cols=2)
        rows = [
            ("CVEs", ", ".join(article.cves) if article.cves else "None identified in available metadata"),
            ("ATT&CK IDs", ", ".join(article.attack_ids) if article.attack_ids else "None confidently mapped from available metadata"),
            ("Targeted Systems", "; ".join(article.targeted_systems)),
            ("Exploitation Requirements", "; ".join(article.exploitation_prerequisites)),
            ("Ranking Basis", f"Impact score {article.impact_score}; relevance score {article.relevance_score}; total score {article.total_score}")
        ]
        for row_index, (label, value) in enumerate(rows):
            add_cell_text(table.rows[row_index].cells[0], label, bold=True)
            add_cell_text(table.rows[row_index].cells[1], value)
        format_table(table)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    document.save(output_path)


def load_input_json(path: Path, hours: int) -> list[Article]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    articles = extract_articles(payload)
    cutoff = utc_now() - dt.timedelta(hours=hours)
    return filter_recent_articles(articles, cutoff)


def write_json_report(articles: list[Article], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for article in articles:
        rows.append({
            "title": article.title,
            "url": article.url,
            "source": article.source,
            "published": article.published.isoformat() if article.published else None,
            "summary": summarize_article(article),
            "cves": article.cves,
            "attack_ids": article.attack_ids,
            "targeted_systems": article.targeted_systems,
            "exploitation_prerequisites": article.exploitation_prerequisites,
            "impact_score": article.impact_score,
            "relevance_score": article.relevance_score,
            "total_score": article.total_score
        })
    path.write_text(json.dumps(rows, indent=2), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a last-18-hours CTI newsletter.")
    parser.add_argument("--hours", type=int, default=18, help="Lookback window in hours.")
    parser.add_argument("--top", type=int, default=4, help="Number of articles to include.")
    parser.add_argument("--count", type=int, default=100, help="Maximum Feedly search articles to request.")
    parser.add_argument("--input-json", type=Path, help="Use a saved Feedly JSON payload instead of calling Feedly.")
    parser.add_argument("--output", type=Path, default=Path("output/cti_quick_newsletter.docx"))
    parser.add_argument("--json-report", type=Path, default=Path("output/cti_quick_newsletter.json"))
    args = parser.parse_args()

    if args.input_json:
        articles = load_input_json(args.input_json, args.hours)
    else:
        token = os.environ.get("FEEDLY_API_KEY") or os.environ.get("FEEDLY_TOKEN")
        if not token:
            print("FEEDLY_API_KEY is required unless --input-json is provided.", file=sys.stderr)
            return 2
        articles = fetch_feedly_articles(token, args.hours, args.count)

    ranked = rank_articles(articles)[:args.top]
    if not ranked:
        print("No relevant articles found for the requested time window.", file=sys.stderr)
        return 1

    write_newsletter(ranked, args.output, args.hours)
    write_json_report(ranked, args.json_report)

    print(f"Newsletter written to: {args.output}")
    print(f"JSON report written to: {args.json_report}")
    for index, article in enumerate(ranked, start=1):
        print(textwrap.shorten(f"{index}. {article.title} [{article.total_score}]", width=120))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
