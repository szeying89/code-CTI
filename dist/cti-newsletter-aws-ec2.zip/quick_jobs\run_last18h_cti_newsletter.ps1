$ErrorActionPreference = "Stop"

$Python = "C:\Users\luvbo\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
$Script = Join-Path $PSScriptRoot "last18h_cti_newsletter.py"

if (-not $env:FEEDLY_API_KEY -and -not $env:FEEDLY_TOKEN) {
    Write-Error "Set FEEDLY_API_KEY or FEEDLY_TOKEN before running this quick job."
}

& $Python $Script --hours 18 --top 4 --output "output\cti_quick_newsletter.docx" --json-report "output\cti_quick_newsletter.json"
