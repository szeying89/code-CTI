# Last 18h CTI Newsletter Quick Job

This quick job collects recent Feedly cybersecurity articles, ranks them by impact and relevance to cyberattack, supply-chain attack, cybercrime, and vulnerability exploitation, then creates a Word newsletter for the top 4 articles.

## Requirements

- `FEEDLY_API_KEY` or `FEEDLY_TOKEN` environment variable.
- Bundled Codex Python runtime with `python-docx`.

## Run

```powershell
$env:FEEDLY_API_KEY="your_feedly_token"
& "C:\Users\luvbo\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" quick_jobs\last18h_cti_newsletter.py --hours 18 --top 4
```

Outputs:

- `output/cti_quick_newsletter.docx`
- `output/cti_quick_newsletter.json`

## Offline Or Saved Payload Mode

If you already have a Feedly JSON export, run:

```powershell
& "C:\Users\luvbo\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" quick_jobs\last18h_cti_newsletter.py --input-json path\to\feedly_payload.json --hours 18 --top 4
```

## Ranking Logic

The job prioritizes:

- Active exploitation, ransomware, zero-days, RCE, and critical vulnerabilities.
- Supply-chain compromise, dependency abuse, package ecosystem attacks, and trusted update abuse.
- Cybercrime and financially relevant activity.
- CVE presence, inferred MITRE ATT&CK IDs, and publication recency.

The job excludes articles centered on ICS, OT, SCADA, PLC, DCS, industrial control systems, and operational technology.
